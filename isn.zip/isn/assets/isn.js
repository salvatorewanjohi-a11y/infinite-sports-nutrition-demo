// Keep the free-delivery bar in step with the cart block as quantities change.
( function () {
	const freeAt = ( window.ISN && Number( window.ISN.freeAt ) ) || 15000;
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-KE' );

	function render( total ) {
		const left = Math.max( 0, freeAt - total );
		const pct = Math.min( 100, Math.round( ( total / freeAt ) * 100 ) );
		const msg = left > 0
			? 'Add <strong>' + fmt( left ) + '</strong> more for <strong>free Nairobi express delivery</strong>'
			: "<strong>You've unlocked free Nairobi express delivery!</strong>";
		document.querySelectorAll( '[data-isn-freebar]' ).forEach( ( el ) => {
			el.innerHTML = msg + '<div class="isn-freebar__track"><div class="isn-freebar__fill" style="width:' + pct + '%"></div></div>';
		} );
	}

	function watch() {
		const data = window.wp && window.wp.data;
		if ( ! data || ! data.select( 'wc/store/cart' ) ) return;
		let last = null;
		data.subscribe( () => {
			const totals = data.select( 'wc/store/cart' ).getCartTotals();
			if ( ! totals || totals.total_items === undefined ) return;
			const minor = Math.pow( 10, totals.currency_minor_unit || 0 );
			const sub = Number( totals.total_items ) / minor;
			if ( sub !== last ) {
				last = sub;
				render( sub );
			}
		} );
	}

	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', watch );
	else watch();
} )();
