<?php
/**
 * Infinite Sports Nutrition child theme.
 */

const ISN_FREE_DELIVERY = 15000; // KSh, keep in step with the Free Nairobi Express Delivery shipping method.
const ISN_LOW_STOCK     = 3;

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'isn-fonts', 'https://fonts.googleapis.com/css2?family=Anton&family=Inter:wght@400;500;600;700&display=swap', [], null );
	wp_enqueue_style( 'isn', get_stylesheet_uri(), [], filemtime( get_stylesheet_directory() . '/style.css' ) );
	wp_enqueue_script( 'isn', get_stylesheet_directory_uri() . '/assets/isn.js', [], filemtime( get_stylesheet_directory() . '/assets/isn.js' ), true );
	wp_localize_script( 'isn', 'ISN', [ 'freeAt' => ISN_FREE_DELIVERY ] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'isn-fonts', 'https://fonts.googleapis.com/css2?family=Anton&family=Inter:wght@400;500;600;700&display=swap', [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

/**
 * Total stock across a product's variations, or null when stock isn't tracked.
 */
function isn_stock_total( WC_Product $product ) {
	if ( $product->is_type( 'variable' ) ) {
		$total   = 0;
		$tracked = false;
		foreach ( $product->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( $v && $v->managing_stock() ) {
				$tracked = true;
				$total  += max( 0, (int) $v->get_stock_quantity() );
			}
		}
		return $tracked ? $total : null;
	}
	return $product->managing_stock() ? max( 0, (int) $product->get_stock_quantity() ) : null;
}

function isn_badges_html( WC_Product $product ) {
	$html = '';
	$spec = get_post_meta( $product->get_id(), '_isn_spec_badge', true );
	if ( $spec ) {
		$html .= '<span class="isn-badge isn-badge--spec">' . esc_html( $spec ) . '</span>';
	}
	$qty = isn_stock_total( $product );
	if ( ! $product->is_in_stock() || $qty === 0 ) {
		$html .= '<span class="isn-badge isn-badge--out">Out of stock</span>';
	} elseif ( $qty !== null && $qty <= ISN_LOW_STOCK ) {
		$html .= '<span class="isn-badge isn-badge--low">Low stock – only ' . $qty . ' left</span>';
	} else {
		$html .= '<span class="isn-badge isn-badge--in">In stock</span>';
	}
	return '<div class="isn-badges">' . $html . '</div>';
}

// Spec + live stock badges above the price on product cards and the product page.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	$product = $id ? wc_get_product( $id ) : null;
	if ( ! $product || is_admin() ) {
		return $content;
	}
	return isn_badges_html( $product ) . $content;
}, 10, 3 );

// Branded placeholder art for products that have no photo yet.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	if ( ! $id || has_post_thumbnail( $id ) ) {
		return $content;
	}
	$product = wc_get_product( $id );
	if ( ! $product ) {
		return $content;
	}
	$brands = get_the_terms( $id, 'product_brand' );
	$brand  = $brands && ! is_wp_error( $brands ) ? $brands[0]->name : '';
	$art    = '<span class="isn-ph"><span><small>' . esc_html( $brand ) . '</small>' . esc_html( $product->get_name() ) . '</span></span>';
	// Keep the sale badge and link that the block wraps around the image.
	$replaced = preg_replace( '/<img[^>]*>/', $art, $content, 1 );
	return $replaced ?: $content;
}, 10, 3 );

// Free delivery progress bar above the cart and in the mini cart.
function isn_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	return '<div class="isn-freebar" data-isn-freebar>' . isn_freebar_inner( $total ) . '</div>';
}
function isn_freebar_inner( $total ) {
	$left = max( 0, ISN_FREE_DELIVERY - $total );
	$pct  = min( 100, round( $total / ISN_FREE_DELIVERY * 100 ) );
	$msg  = $left > 0
		? 'Add <strong>KSh ' . number_format( $left ) . '</strong> more for <strong>free Nairobi express delivery</strong>'
		: '<strong>You\'ve unlocked free Nairobi express delivery!</strong>';
	return $msg . '<div class="isn-freebar__track"><div class="isn-freebar__fill" style="width:' . $pct . '%"></div></div>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => isn_freebar_html() . $c );

// Newsletter: store the email and hand over the KSh 500 welcome code.
add_action( 'admin_post_nopriv_isn_subscribe', 'isn_subscribe' );
add_action( 'admin_post_isn_subscribe', 'isn_subscribe' );
function isn_subscribe() {
	check_admin_referer( 'isn_subscribe' );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$back  = wp_get_referer() ?: home_url( '/' );
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'isn_sub', 'invalid', $back ) . '#newsletter' );
		exit;
	}
	$list = get_option( 'isn_subscribers', [] );
	$list[ strtolower( $email ) ] = current_time( 'mysql' );
	update_option( 'isn_subscribers', $list, false );
	wp_safe_redirect( add_query_arg( 'isn_sub', 'ok', $back ) . '#newsletter' );
	exit;
}

add_shortcode( 'isn_newsletter', function () {
	$state = sanitize_key( $_GET['isn_sub'] ?? '' );
	if ( $state === 'ok' ) {
		return '<p class="isn-news-ok"><strong>You\'re in!</strong> Use code <strong style="color:var(--wp--preset--color--accent)">WELCOME500</strong> at checkout for KSh 500 off your first order.</p>';
	}
	$err = $state === 'invalid' ? '<p style="color:#f87171;margin:.5rem 0 0">Please enter a valid email address.</p>' : '';
	return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="isn_subscribe">'
		. wp_nonce_field( 'isn_subscribe', '_wpnonce', true, false )
		. '<input type="email" name="email" required placeholder="Your email address" aria-label="Email address">'
		. '<button class="wp-element-button" type="submit">Get KSh 500 off</button>'
		. '</form>' . $err;
} );

// Staff see the subscriber list under WooCommerce.
add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Newsletter subscribers', 'Subscribers', 'manage_woocommerce', 'isn-subscribers', function () {
		$list = get_option( 'isn_subscribers', [] );
		echo '<div class="wrap"><h1>Newsletter subscribers (' . count( $list ) . ')</h1><table class="widefat striped"><thead><tr><th>Email</th><th>Signed up</th></tr></thead><tbody>';
		foreach ( array_reverse( $list, true ) as $email => $when ) {
			echo '<tr><td>' . esc_html( $email ) . '</td><td>' . esc_html( $when ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

// Same placeholder art on the single product page gallery.
add_filter( 'woocommerce_single_product_image_thumbnail_html', function ( $html, $attachment_id ) {
	global $product;
	if ( $attachment_id || ! $product ) {
		return $html;
	}
	$brands = get_the_terms( $product->get_id(), 'product_brand' );
	$brand  = $brands && ! is_wp_error( $brands ) ? $brands[0]->name : '';
	return '<div class="woocommerce-product-gallery__image--placeholder"><span class="isn-ph isn-ph--lg"><span><small>' . esc_html( $brand ) . '</small>' . esc_html( $product->get_name() ) . '</span></span></div>';
}, 10, 2 );

// Kenyan addresses: no postcode, and riders need a phone number.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate (e.g. Westlands, Kilimani)' ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon: the shop's Instagram logo.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/logo.jpg' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
